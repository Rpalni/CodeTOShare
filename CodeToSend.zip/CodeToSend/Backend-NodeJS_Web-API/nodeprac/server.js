const express = require("express");
const app = express();

var cors = require('cors')
app.use(cors())

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());


var users = [];
app.get("/users", (req, res) => {
  res.send(
    users
  );
});

app.post("/users", (req, res) => {

  const user = {
    id: users.length + 1,
    name: req.body.user.name,
    email: req.body.user.email,
    phone: req.body.user.phone
  }

  users.push(user);
  res.json(user);

});

app.post("/login", (req, res) => {

  if (req.body.user.email != 'rpalni@gmail.com' || req.body.user.password != '1234') {
    res.json(null);
  }
  else {
    res.json(users);
  }
});

app.delete("/users/:id", (req, res) => {

  var requestId = req.params.id;

  let contact = users.filter(contact => {
    return contact.id == requestId;
  })[0];

  const index = users.indexOf(contact);
  users.splice(index, 1);
  res.json(users);
});


app.listen("3004");
