import React, { Component } from 'react';
import { loginUser } from '../redux/action/um_action';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import Header from './header';

class Login extends Component {
    constructor(props) {
        super(props)

        this.state = {
            email: "",
            password: "",
            message: ""
        };
    }


    handleEmailChange = (e) => {
        this.setState({
            email: e.target.value
        })
    }
    handlePasswordChange = (e) => {
        this.setState({
            password: e.target.value
        })
    }

    handleSubmit = (e) => {
        e.preventDefault()
        this.props.loginUser(this.state.email, this.state.password)

        if (this.props.logindetails == null) {
            this.setState({ message: 'Log in Failed. Try again!' })
        }

    }

    render() {

        if (this.props.logindetails != null) {
            //this.props.history.push('./user');
            return <Redirect to='/user' />
        }

        return (
            <div className="container">
                <div className="jumbotron">
                    <Header />
                </div>

                <form class="list-group" onSubmit={this.handleSubmit}>
                    <div className="row">
                        <div className="col-sm-1">
                            Email:
                        </div>
                        <div className="col-sm-1">
                            <input type="text" onChange={this.handleEmailChange} value={this.state.email}></input>
                        </div>
                    </div><br />
                    <div className="row">
                        <div className="col-sm-1">
                            Password
                        </div>
                        <div className="col-sm-1">
                            <input type="password" onChange={this.handlePasswordChange} value={this.state.password}></input>
                        </div>
                    </div><br />
                    <p><input type="submit" value="Login"></input></p>

                    <p><label id="lblMessage">{this.state.message}</label></p>
                </form>
            </div >
        );
    }
}

const mapStateToProps = (state) => {
    console.log(state.logindetails)
    console.log('raju')

    return {
        logindetails: state.logindetails
    }
}

export default connect(mapStateToProps, { loginUser })(Login);