import React, { Component } from 'react';
import { addUser } from '../redux/action/um_action';
import { connect } from 'react-redux';
import Header from './header';


class AddUser extends Component {
    constructor(props) {
        super(props)

        this.state = {
            name: "",
            email: "",
            phone: "",
            message: ""
        };

    }


    handleNameChange = (e) => {
        this.setState({
            name: e.target.value
        })
    }
    handleEmailChange = (e) => {
        this.setState({
            email: e.target.value
        })
    }
    handlePhoneChange = (e) => {
        this.setState({
            phone: e.target.value
        })
    }

    handleSubmit = (e) => {
        e.preventDefault()
        this.props.addUser(this.state.name, this.state.email, this.state.phone)
        this.setState({ name: '', email: '', phone: '', message: 'User Successfully Added' })

    }

    render() {
        return (
            <div className="container">
                <div className="jumbotron">
                    <Header />
                </div>
                <form class="list-group" onSubmit={this.handleSubmit}>

                    <div className="row">
                        <div className="col-sm-1">
                            Name:
                        </div>
                        <div className="col-sm-1">
                            <input type="text" onChange={this.handleNameChange} value={this.state.name}></input>
                        </div>
                    </div><br />
                    <div className="row">
                        <div className="col-sm-1">
                            Email:
                        </div>
                        <div className="col-sm-1">
                            <input type="text" onChange={this.handleEmailChange} value={this.state.email}></input>
                        </div>
                    </div><br />
                    <div className="row">
                        <div className="col-sm-1">
                            Phone:</div>
                        <div className="col-sm-1"><input type="text" onChange={this.handlePhoneChange} value={this.state.phone}></input>
                        </div>
                    </div ><br />
                    <p><input type="submit" value="Add User"></input></p>
                    <p><label id="lblMessage">{this.state.message}</label></p>

                </form >
            </div >
        );
    }
}

const mapStateToProps = (state) => {
    console.log(state.users)
    return {
        users: state.users
    }
}

export default connect(mapStateToProps, { addUser })(AddUser);