import React from 'react';
import { BrowserRouter as Router } from "react-router-dom";

function Header() {

    var currentRoute = window.location.pathname;
    var pageHeading = "Login Page";
    var isVisible = false;


    if (currentRoute === "/adduser") {
        pageHeading = "Add User";
        isVisible = true;
    }
    else if (currentRoute === "/user") {
        pageHeading = "User List";
        isVisible = true;
    }

    return (
        <Router>
            <div>
                <h1><center>User Management System</center></h1><br />
                <h3><strong>{pageHeading}</strong></h3>

                {isVisible ? <p> <a href="./user">User List</a> | <a href="./adduser">Add User</a></p> : <p></p>
                }
            </div>
        </Router >

    );
}

export default Header;
