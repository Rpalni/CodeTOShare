import React, { Component } from 'react';
import { getAllUsers, deleteUser } from '../redux/action/um_action';
import { connect } from 'react-redux';
import Header from './header';


class UserList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            user: {
                name: "Raju"
            }
        };
        this.handleDelete = this.handleDelete.bind(this);
    }

    componentDidMount() {
        this.props.getAllUsers()
    }

    handleDelete = (userid) => {
        this.props.deleteUser(userid)
        this.props.getAllUsers()

    }

    render() {

        if (!this.props.users) {
            return <div>Loading....</div>
        }

        return (
            <div className="container">
                <div className="jumbotron">
                    <Header />
                </div>

                <ul className="list-group">
                    {
                        this.props.users.map(user => (<div key={user.id}>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <strong>Name:</strong>{user.name}<strong>Phone</strong>{user.phone}
                                <strong>Email:</strong>{user.email}
                                <button className="badge badge-primary badge-pill"
                                    onClick={this.handleDelete.bind(this, user.id)}>Delete</button>
                            </li>
                        </div>
                        )
                        )
                    }
                </ul>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    console.log(state.users)
    return {
        users: state.users
    }
}

export default connect(mapStateToProps, { getAllUsers, deleteUser })(UserList);