import React from 'react';
import UserList from './component/userList';
import AddUser from './component/addUser';
import Login from './component/login';
import { BrowserRouter as Router, Route } from 'react-router-dom';

function App() {

  return (
    <Router>
      <Route exact path="/" component={Login} />
      <Route path="/user" component={UserList} />
      <Route path="/adduser" component={AddUser} />
    </Router>
  );

}

export default App;
