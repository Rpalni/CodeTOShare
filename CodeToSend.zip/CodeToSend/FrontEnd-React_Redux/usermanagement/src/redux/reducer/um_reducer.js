
let initialState = {
    users: null
}
export default (state = initialState, action) => {
    switch (action.type) {
        case "GET_USERS":
            return {
                ...state,
                users: action.payload
            }
        case "ADD_USER":
            return {
                ...state,
                users: action.payload
            }
        case "DELETE_USER":
            return {
                ...state,
                users: action.payload
            }
        case "LOGIN_USER":
            return {
                ...state,
                logindetails: action.payload
            }

        default:
            return state
    }
}