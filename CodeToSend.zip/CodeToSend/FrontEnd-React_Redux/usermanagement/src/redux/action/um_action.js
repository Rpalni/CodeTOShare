export const getAllUsers = () => {
    return dispatch => {
        fetch("http://localhost:3004/users")
            .then(res => res.json())
            .then(data => dispatch(getUsers(data)))
    }
}
const getUsers = (users) => {
    return { type: "GET_USERS", payload: users }
}


export const deleteUser = (id) => {
    return dispatch => {
        fetch('http://localhost:3004/users/' + id, {
            method: 'DELETE',
        })
            .then(res => res.json())
            .then(data => deleteNewUser(data))

    }
}
const deleteNewUser = (deleteUser) => {
    return { type: "DELETE_USER", payload: deleteUser }
}


export const addUser = (name, email, phone) => {
    return dispatch => {
        fetch("http://localhost:3004/users", {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                user: {
                    name: name,
                    email: email,
                    phone: phone
                }
            })
        })
            .then(res => res.json())
            .then(data => dispatch(addNewUser(data)))
    }
}
const addNewUser = (newUser) => {
    return { type: "ADD_USER", payload: newUser }
}


export const loginUser = (email, password) => {
    return dispatch => {
        fetch("http://localhost:3004/login", {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                user: {
                    email: email,
                    password: password
                }
            })
        })
            .then(res => res.json())
            .then(data => dispatch(loginNewUser(data)))
    }
}
const loginNewUser = (loginUser) => {
    return { type: "LOGIN_USER", payload: loginUser }
}